package br.com.premiereflamengo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val red = Color.rgb(183, 0, 37)
    private val dark = Color.rgb(12, 14, 20)
    private val panel = Color.rgb(26, 30, 40)
    private val muted = Color.rgb(190, 197, 208)
    private val channelId = "premiere_flamengo_alerts"
    private var kickoffMillis: Long? = null
    private var timer: CountDownTimer? = null
    private val sent = mutableSetOf<String>()
    private lateinit var countdown: TextView
    private lateinit var status: TextView
    private lateinit var timeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(dark) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val badge = TextView(this).apply {
            text = "⚽"; textSize = 27f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(red)
            val p = dp(48); layoutParams = LinearLayout.LayoutParams(p, p)
        }
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        names.addView(text("PREMIERE FLAMENGO", 19f, Color.WHITE, true))
        names.addView(text("CENTRAL DA NAÇÃO RUBRO-NEGRA", 10f, muted, false))
        header.addView(badge); header.addView(names)
        page.addView(header)
        page.addView(space(18))

        val hero = card()
        hero.addView(text("🔴⚫  DIA DE MENGÃO", 12f, Color.rgb(255, 210, 220), true))
        hero.addView(space(8))
        hero.addView(text("O jogo começa aqui.", 26f, Color.WHITE, true))
        hero.addView(space(6))
        hero.addView(text("Acesse transmissões oficiais, acompanhe a preparação e programe lembretes da partida.", 14f, muted, false))
        page.addView(hero)
        page.addView(section("📺  TRANSMISSÃO OFICIAL"))

        val player = card()
        val videoPlaceholder = TextView(this).apply {
            text = "⚽\n\nESCOLHA UMA TRANSMISSÃO OFICIAL\n\nO vídeo abre no canal autorizado. A disponibilidade depende dos direitos de cada partida e da região."
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(dp(16), dp(28), dp(16), dp(28))
            setBackgroundColor(Color.rgb(4, 5, 8))
        }
        player.addView(videoPlaceholder)
        player.addView(space(12))
        player.addView(button("▶  FLAMENGO TV", red) {
            openUrl("https://www.youtube.com/@flamengo/live")
        })
        player.addView(space(8))
        player.addView(button("▶  CANAL GOAT", Color.rgb(48, 56, 72)) {
            openUrl("https://www.youtube.com/@canalgoat/live")
        })
        page.addView(player)

        page.addView(section("⏱️  CONTAGEM REGRESSIVA"))
        val clock = card()
        clock.addView(text("Defina a data e o horário local da partida:", 12f, muted, false))
        clock.addView(space(8))
        timeButton = button("ESCOLHER DATA E HORÁRIO", Color.rgb(48, 56, 72)) { chooseDateTime() }
        clock.addView(timeButton)
        countdown = text("--:--:--", 30f, Color.WHITE, true)
        countdown.setPadding(0, dp(12), 0, dp(3))
        clock.addView(countdown)
        status = text("Aguardando horário da partida.", 11f, muted, false)
        clock.addView(status)
        clock.addView(space(10))
        clock.addView(button("ATIVAR AVISOS", red) { requestNotificationPermissionIfNeeded(); notifyUser("Avisos ativados", "Deixe o aplicativo aberto para acompanhar os lembretes.") })
        page.addView(clock)

        page.addView(section("🏟️  RITUAL DO JOGO"))
        val rituals = card()
        rituals.addView(text("🔥  Aquecimento dos jogadores", 14f, Color.WHITE, true))
        rituals.addView(text("🎶  Hino e entrada dos times", 14f, Color.WHITE, true))
        rituals.addView(text("⚽  Primeiro tempo e intervalo", 14f, Color.WHITE, true))
        rituals.addView(text("🔴  Segundo tempo e encerramento", 14f, Color.WHITE, true))
        rituals.addView(space(7))
        rituals.addView(text("Use os canais oficiais para assistir à cobertura pré-jogo quando estiver disponível.", 11f, muted, false))
        page.addView(rituals)

        page.addView(section("🔔  AVISOS PROGRAMADOS"))
        val alerts = card()
        listOf(
            "5 minutos antes — abrir a cobertura e acompanhar a preparação",
            "Horário inicial — lembrete do início previsto do jogo",
            "60 minutos depois — previsão estimada do segundo tempo",
            "105 minutos depois — previsão estimada do fim"
        ).forEach { alerts.addView(text("•  $it", 12f, Color.WHITE, false)); alerts.addView(space(7)) }
        page.addView(alerts)

        page.addView(space(12))
        page.addView(text("IMPORTANTE: o app não hospeda nem retransmite partidas. Para evitar atraso extra, abre diretamente os canais oficiais. Não há garantia de zero delay. Os lembretes são estimados e dependem de o aplicativo permanecer aberto; o início real, hino, gols e mudanças de tempo não são detectados automaticamente.", 11f, muted, false))
        page.addView(space(18))
        page.addView(text("PREMIERE FLAMENGO • Feito para a Nação ❤️🖤", 10f, muted, false).apply { gravity = Gravity.CENTER })
    }

    private fun chooseDateTime() {
        val now = Calendar.getInstance()
        android.app.DatePickerDialog(this, { _, y, m, d ->
            android.app.TimePickerDialog(this, { _, hour, minute ->
                val cal = Calendar.getInstance().apply {
                    set(y, m, d, hour, minute, 0); set(Calendar.MILLISECOND, 0)
                }
                kickoffMillis = cal.timeInMillis
                sent.clear()
                timeButton.text = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(kickoffMillis!!))
                startCountdown()
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun startCountdown() {
        timer?.cancel()
        val target = kickoffMillis ?: return
        timer = object : CountDownTimer((target - System.currentTimeMillis()).coerceAtLeast(0) + 1000, 1000) {
            override fun onTick(millis: Long) {
                val remaining = (target - System.currentTimeMillis()).coerceAtLeast(0)
                val sec = remaining / 1000
                countdown.text = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
                status.text = "Tempo restante para o início previsto."
                if (remaining <= 5 * 60 * 1000L) sendOnce("pre", "Faltam 5 minutos!", "Abra a transmissão oficial e acompanhe a preparação.")
                if (remaining == 0L) sendOnce("start", "Início previsto do jogo", "Confira a transmissão oficial.")
                val elapsed = System.currentTimeMillis() - target
                if (elapsed >= 60 * 60 * 1000L) sendOnce("second", "Segundo tempo (estimado)", "O intervalo pode variar; confira a transmissão.")
                if (elapsed >= 105 * 60 * 1000L) sendOnce("end", "Fim previsto da partida", "O tempo é estimado e pode variar.")
            }
            override fun onFinish() { countdown.text = "00:00:00"; status.text = "Horário previsto alcançado." }
        }.start()
    }

    private fun sendOnce(key: String, title: String, body: String) {
        if (sent.add(key)) notifyUser(title, body)
    }

    private fun notifyUser(title: String, body: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, channelId) else android.app.Notification.Builder(this)
        val notification = builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title).setContentText(body).setContentIntent(intent).setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Avisos do jogo", NotificationManager.IMPORTANCE_DEFAULT)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir o canal.", Toast.LENGTH_SHORT).show() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); layoutParams = lp
    }
    private fun section(s: String) = text(s, 15f, Color.WHITE, true).apply {
        setPadding(dp(2), dp(18), 0, dp(8))
    }
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1f)
    }
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(color)
        isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
