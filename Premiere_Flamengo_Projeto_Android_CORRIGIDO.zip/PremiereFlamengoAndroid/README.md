# Premiere Flamengo — projeto Android

Projeto-fonte Android em Kotlin para abrir no Android Studio e compilar como APK.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `PremiereFlamengoAndroid`.
4. Aguarde a sincronização do Gradle.
5. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## O que o app faz
- Interface Android com identidade vermelha e preta.
- Atalhos para as páginas ao vivo da Flamengo TV e do Canal GOAT.
- Seletor de data/hora e contagem regressiva.
- Notificações estimadas enquanto o app está aberto.
- Ícone de inicialização.

## Limitações importantes
- Este projeto não contém sinal de TV nem retransmite jogos.
- A disponibilidade de imagem depende dos direitos de cada partida, da região e do canal.
- O app abre diretamente os canais oficiais para evitar uma etapa intermediária, mas não pode garantir zero delay.
- Os avisos do segundo tempo e fim são estimativas; o app não detecta eventos reais.
- Para notificações confiáveis em segundo plano seria necessário adicionar um backend/serviço de dados e agendamento adequado.
